package by.belstu.view;

public class Printer {

    public void print(String str){
        System.out.print(str);
    }

    public void println(String str){
        System.out.println(str);
    }
}
